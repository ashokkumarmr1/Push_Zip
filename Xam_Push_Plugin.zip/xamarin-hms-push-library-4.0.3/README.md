# Huawei Xamarin Push Library

## Contents
- Introduction
- Installation
- Configuration
- API Reference
- Licensing and Terms

## 1. Introduction
The Xamarin SDK wraps the Android SDK with Managed Callable Wrappers through the usage of Android Bindings Library projects. It provides the same APIs as the native SDK.

The Xamarin SDK libraries are described as follows:

- Library .DLL files: These are the files enable the usage of the native Android SDK interfaces. Once generated, these files can be referenced & used directly in a Xamarin.Android project.

## 2. Installation
Before using the Xamarin SDK code, ensure that Visual Studio 2019 is installed with "Mobile development with .NET" support.

### 2.1 Download native Android SDK packages
The Push SDK and its dependencies must be downloaded from the Huawei repository.
Use the following URLs to download the packages.
- [push-4.0.2.300.aar](https://developer.huawei.com/repo/com/huawei/hms/push/4.0.2.300/push-4.0.2.300.aar)
- [agconnect-core-1.0.0.300.aar](https://developer.huawei.com/repo/com/huawei/agconnect/agconnect-core/1.0.0.300/agconnect-core-1.0.0.300.aar)
- [base-4.0.2.300.aar](https://developer.huawei.com/repo/com/huawei/hms/base/4.0.2.300/base-4.0.2.300.aar)
- [network-common-4.0.2.300.aar](https://developer.huawei.com/repo/com/huawei/hms/network-common/4.0.2.300/network-common-4.0.2.300.aar)
- [network-grs-4.0.2.300.aar](https://developer.huawei.com/repo/com/huawei/hms/network-grs/4.0.2.300/network-grs-4.0.2.300.aar)
- [opendevice-4.0.1.301.aar](https://developer.huawei.com/repo/com/huawei/hms/opendevice/4.0.1.301/opendevice-4.0.1.301.aar)
- [tasks-1.3.3.300.aar](https://developer.huawei.com/repo/com/huawei/hmf/tasks/1.3.3.300/tasks-1.3.3.300.aar)
- [update-2.0.6.300.aar](https://developer.huawei.com/repo/com/huawei/hms/update/2.0.6.300/update-2.0.6.300.aar)

### 2.2 Open the library project
An Android Bindings Library project for Xamarin allows the usage of only one .aar file. For this reason the library repository comes with multiple library projects. 

Open up Visual Studio 2019. Then from the menu;
	
- Click "Open a project or a solution"
- Navigate to the directory where you cloned the repository and open "XPush-4.0.2.300.csproj".

### 2.3 Import the downloaded packages
Once you open the library project for the Push SDK, each package you downloaded in the first step must placed under its related library project.

Inside the "Solution Explorer", expand each project and repeat the steps below:
- Right click "Jars" -> "Add" -> "Existing Item" (Shift + Alt + A)
- Navigate to the folder where you downloaded the packages and select the related .aar or .jar file.	
    
         Example: For XTasks-1.3.3.300 project, import "tasks-1.3.3.300.aar"
- Click on the package file you just imported. 
		In the **properties** window, 
			
    - set the Build Action as "LibraryProjectZip" if the file type is .aar
	- set the Build Action as "EmbeddedJar" if the file type is .jar

- Repeat the steps for **each of the three projects**.

### 2.4 Build the library.
From the Visual Studio's toolbar, click "Build" -> "Build Solution" (Ctrl + Shift + B).
Once the build process is complete, generated classes should be visible in the object browser.

(View -> Object Browser) (Ctrl + Alt + J)

### 2.5 Using the library
There are two ways to use the Push SDK after the .dll files are generated.

#### 2.5.1 Reference the generated library files
You can add the generated .dll files as references to your project directly.
- Expand the solution of your Xamarin.Android app, then right click "References" -> "Add"
- In the Reference Manager window that just opened, click the "Browse" button at the bottom.
- Navigate to the directory of the XPush-4.0.2.300 library project. Based on your choice of build type (Debug or Release), the generated .dll files will inside on of the following directories:
    - XPush-4.0.2.300\bin\\**Debug**
    - XPush-4.0.2.300\bin\\**Release**
- Select all of the generated .dll files. Click "OK", then you should be able to use the classes from the libraries you just imported.

#### 2.5.2 Reference the projects
You can add the library projects to the solution of your Xamarin.Android application, then add the projects as a reference.

- From the Visual Studio's toolbar, click "File" -> "Add" -> "Existing Project"
- Navigate to the directory where the library projects reside, then select the **.csproj** file of one of the library projects.
         
         Example: For XTasks-1.3.3.300 project, select "XTasks-1.3.3.300.csproj"
- Expand the solution of your Xamarin.Android app, then right click "References" -> "Add"
- In the Reference Manager window that just opened, click "Projects" then select the project you just added to your solution. Click "OK", then you should be able to use the classes from the library you just imported.
- Repeat the above steps **for each of the library projects.**

## 3. Configuration
No.

## 4. API Reference
| HmsInstanceId | This class provides methods for obtaining the AAID of an app and obtaining tokens required for accessing HUAWEI Push Kit. |
| :-: | :-: |
| GetInstance(Context context) | Obtains the instance of the HmsInstanceId class. If the instance does not exist, it will be created. Other methods such as Id and Token in this class can be called only after this instance is obtained. |
| Id | Obtains an AAID in synchronous mode. |
| Task<AAID> | Obtains an AAID in asynchronous mode. |
| CreationTime | Obtains the generation timestamp of an AAID. |
| DeleteAAID() | Deletes a local AAID and its generation timestamp. |
| Token | Obtains a token. This method is not recommended. You are advised to use the GetToken(string appId, string scope) method to obtain tokens. |
| GetToken(string appId, string scope) | Obtains a token required for accessing HUAWEI Push Kit. |
| DeleteToken(string appId, string scope) | Deletes a token. |


| AAIDResult | This class bears and returns AAIDs obtained through the HmsInstanceId.AAID method. You can call the Id method in the AAIDResult class to obtain an AAID.
| :-: | :-: |
| Id | Obtains the AAID of an app. |


| HmsMessaging | This class provides methods for subscribing to topics and enables or disables the function of receiving notification messages. |
| :-: | :-: |
| GetInstance(Context context) | Obtains the instance. |
| AutoInitEnabled | Checks whether automatic initialization is enabled or not. |
| Subscribe(string topic) | Subscribes to topics in asynchronous mode. |
| Unsubscribe(string topic) | Unsubscribes from topics in asynchronous mode. |
| TurnOnPush() | Enables the function of receiving notification messages in asynchronous mode. |
| TurnOffPush() | Disables the function of receiving notification messages in asynchronous mode. |


| HmsMessageService | Basic class of HUAWEI Push Kit for receiving messages. |
| :-: | :-: |
| OnMessageReceived(RemoteMessage message) | Receives data messages. |
| OnDeletedMessages() |This method is not implemented currently. |
| OnNewToken(string token) | Callback method used after the server updates the token. |
| OnTokenError(Java.Lang.Exception exception) | Callback method used when a token fails to be applied for. |


| RemoteMessage | This is a message entity class that uses the onMessageReceived(RemoteMessage) method to receive messages sent by the server. |
| :-: | :-: |
| CollapseKey | Obtains the classification identifier (collapse key) of a message. |
| Data | Obtains the payload of a message. |
| DataOfMap | Obtains the payload of a Map message. |
| MessageId | Obtains the ID of a message. |
| MessageType | Obtains the type of a message. |
| GetNotification() | Obtains the notification data instance from a message. |
| OriginalUrgency | Obtains the message priority set by the app. |
| Urgency | Obtains the message priority set on the HUAWEI Push Kit server. |
| Ttl | Obtains the maximum cache duration of a message. |
| SentTime | Obtains the time when a message is sent from the server. |
| To | Obtains the recipient of a message. |
| From | Obtains the resource of a message. |
| Token | Obtains the token in a message. |


| RemoteMessage.Notification | Notification message details in RemoteMessage. |
| :-: | :-: |
| Title | Obtains the title of a message. |
| TitleLocalizationKey | Obtains the key of the localized title of a notification message for message display localization. |
| GetTitleLocalizationArgs() | Obtains variable string values in the localized title of a notification message. |
| BodyLocalizationKey | Obtains the key of the localized content of a notification message for message display localization. |
| GetBodyLocalizationArgs() | Obtains variable string values in the localized content of a message. |
| Body | Obtains the displayed content of a message. |
| Icon | Obtains the image resource name of a notification icon. |
| Sound | Obtains the name of an audio resource to be played when a notification message is displayed. |
| Tag | Obtains the tag from a message for message overwriting. |
| Color | Obtains the colors (in #RRGGBB format) of icons in a message. |
| ClickAction | Obtains the action triggered upon notification message tapping. |
| ChannelId | Obtains IDs of channels that support the display of a message. If no channel is set, null is returned. |
| ImageUrl | Obtains the URL of an image in a message. |
| Link | Obtains the deep link from a message. |
| NotifyId | Obtains the unique ID of a message. |
| IsDefaultLight | Check whether a notification message uses the default notification light settings. |
| IsDefaultSound | Check whether a notification message uses the default sound. |
| IsDefaultVibrate | Check whether a notification message uses the default vibration mode. |
| When | Obtains the time (in milliseconds) when an event occurs from a notification message. |
| GetLightSettings() | Obtains the blinking frequency and color of a breathing light. |
| BadgeNumber | Obtains the number of notification messages. |
| IsAutoCancel | Check whether a notification message is sticky. |
| Importance | Obtains the priority of a notification message. |
| Ticker | Obtains the text to be displayed on the status bar for a notification message. |
| GetVibrateConfig() | Obtains the vibration mode of a message. |
| Visibility | Obtains the visibility of a notification message. |
| IntentUri | Obtains the intent in a notification message. |

You can read more and get detailed information about the interfaces described above from [developer.huawei.com](https://developer.huawei.com)

## 5. Licensing and Terms
Huawei Xamarin SDK uses the Apache 2.0 license.
